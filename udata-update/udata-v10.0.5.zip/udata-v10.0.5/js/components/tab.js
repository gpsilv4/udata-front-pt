import Tab from 'vue-strap/src/Tab.vue';

export default {
    mixins: [Tab],
    props: {
        id: String
    }
};

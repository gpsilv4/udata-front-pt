orgName = "Test org " + Math.random().toString(36).substring(7)
orgDescription = orgName + " description"

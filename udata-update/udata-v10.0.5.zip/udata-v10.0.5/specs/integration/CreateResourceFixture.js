resourceName = "Test resource " + Math.random().toString(36).substring(7)

# metadata extensions mainly
__all__ = ["dri", "mdrpi", "mdui", "shibmd", "idpdisc", "algsupport", "mdattr"]

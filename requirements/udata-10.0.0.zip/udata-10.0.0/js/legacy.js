/**
 * Common stack, plugins and helpers
 */
import $ from 'jquery';  // here only as bootstrap dependency
import 'bootstrap';  // Stil required for navbar, dropdowns, contribute modal and remaining tabsets
import 'i18n';
